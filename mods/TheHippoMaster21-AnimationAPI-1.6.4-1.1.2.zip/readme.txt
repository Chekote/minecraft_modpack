<<AnimationAPI>>
by thehippomaster21

The AnimationAPI is a helper library that allows modders to create unique entity animations in an easier way. Although it is
simpler to make animations using the API than without an API, creating animations is still quite complicated. Users simply
have to download this API and install it like a normal mod.

Changelist:
v1.1.2:
~updated to mc1.6.4